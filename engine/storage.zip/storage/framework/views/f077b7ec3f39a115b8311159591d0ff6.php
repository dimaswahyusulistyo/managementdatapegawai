

<?php $__env->startSection('title', 'Contact Title'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to our website!</h1>
    <p>This is a Contact</p>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('aditional-css'); ?>
    <link rel="stylesheet" href="path-to-aditional-css.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('aditional-js'); ?>
    <script src="path-to-aditional-script.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('pian-app.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coba-app\mesinkita\resources\views/pian-app/contact.blade.php ENDPATH**/ ?>