

<?php $__env->startSection('title', 'AdminLTE 3 | Daftar Jenis Kelamin'); ?>

<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Daftar Jenis Kelamin</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
              <li class="breadcrumb-item active">Daftar Jenis Kelamin</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Daftar Jenis Kelamin</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
              <a href="<?php echo e(url('/formjeniskelamin')); ?>" class="btn btn-primary mb-3">Tambah Jenis Kelamin</a>
              <table class="table table-bordered">
                <thead>
                  <?php $no=1; ?>
                  <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Nama Jenis Kelamin</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $jeniskelamins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jeniskelamin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($no); ?></td>
                    <td><?php echo e($jeniskelamin->id); ?></td>
                    <td><?php echo e($jeniskelamin->jeniskelamin); ?></td>
                    <td>
                      <a href="<?php echo e(route('dimas-app.editjeniskelamin', $jeniskelamin->id)); ?>" class="btn btn-warning">Edit</a>
                      <form action="<?php echo e(route('dimas-app.destroyjeniskelamin', $jeniskelamin->id)); ?>" method="post" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('DELETE'); ?>
                          <button type="submit" class="btn btn-danger delete-button">Hapus</button>
                      </form>
                    </td>
                  </tr>
                  <?php $no++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>

              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('aditional-css'); ?>
    <link rel="stylesheet" href="path-to-aditional-css.css">
  <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/adminlte.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('aditional-js'); ?>
    <script src="path-to-aditional-script.js"></script>
    <!-- jQuery -->
    <script src="plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/adminlte.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js"></script>
<?php $__env->stopPush(); ?>

<script>
    // Menangkap klik tombol Hapus
    const deleteButtons = document.querySelectorAll('.delete-button');
    deleteButtons.forEach(deleteButton => {
        deleteButton.addEventListener('click', (e) => {
            e.preventDefault();
            const confirmationMessage = e.target.getAttribute('data-confirm');
            if (confirm(confirmationMessage)) {
                // Jika pengguna mengonfirmasi, lanjutkan untuk menghapus data
                e.target.parentElement.submit();
            }
        });
    });
</script>
<?php echo $__env->make('dimas-app.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dimas-laravel\engine\resources\views/dimas-app/tablejeniskelamin.blade.php ENDPATH**/ ?>