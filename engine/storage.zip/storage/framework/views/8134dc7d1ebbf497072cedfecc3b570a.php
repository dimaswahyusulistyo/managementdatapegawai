<!-- 

<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to our website!</h1>
    <p>This is a sample page using layout inheritence</p>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('aditional-css'); ?>
    <link rel="stylesheet" href="path-to-aditional-css.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('aditional-js'); ?>
    <script src="path-to-aditional-script.js"></script>
<?php $__env->stopPush(); ?> -->
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coba-app\mesinkita\resources\views/page.blade.php ENDPATH**/ ?>