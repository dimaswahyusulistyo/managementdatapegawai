<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldPushContent('aditional-css'); ?>
</head>
<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">
    </div>    

    <?php echo $__env->yieldPushContent('aditional-js'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\dimas-laravel\engine\resources\views/dimas-app/masterlogin.blade.php ENDPATH**/ ?>