<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldPushContent('aditional-css'); ?>
</head>
<body class="hold-transition dark-mode sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
    <div class="wrapper">
        <?php echo $__env->yieldContent('preloader'); ?>
        <?php echo $__env->make('dimas-app.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('dimas-app.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('dimas-app.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>    

    <?php echo $__env->yieldPushContent('aditional-js'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\dimas-laravel\engine\resources\views/dimas-app/master.blade.php ENDPATH**/ ?>